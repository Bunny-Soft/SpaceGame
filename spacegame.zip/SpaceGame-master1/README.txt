NOTE:
	The values for each ship are set. 
	Further, each variable of the ship can be set (this allows us to change anything if we need to).
		*Variables are protected. 
