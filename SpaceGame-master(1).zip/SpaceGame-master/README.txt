NOTE:
	The combat system is integrated for the most part. Needs to be tweaks and updates here and there, but its mostly done. 
		The power system, i.e. solar and mining also needs a few tweaks as well. 
